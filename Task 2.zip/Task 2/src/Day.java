import java.util.Scanner;

public class Day { 
	
	public static void Day (String[] args) {

    Scanner input = new Scanner(System.in);
    
    //String equals Wednesday, attempted to set the integer to the reduced price of "6"
	String wed = "wednesday";
	
	System.out.print("Please enter the day of the week: ");
	
	if (wed=="wednesday") {
		int standard = 6;
	}
	
	wed = input.nextLine();

}
}
