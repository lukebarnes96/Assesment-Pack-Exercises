import java.util.Scanner;

public class Main {
		
		public static void main (String[] args) {
		
		//Calling Day Class	
		Day DayObject = new Day();
		Day.Day(args);	
			
		//Calling Standard Class	
		Standard StandardObject = new Standard();
		Standard.ticket1(args);
		
		//Calling OAP Class
		OAP OAPObject = new OAP();
		OAP.ticket2(args);
		
		//Calling Student Class
		Student StudentObject = new Student();
		Student.ticket3(args);
		
		//Calling Child class
		Child ChildObject = new Child();
		Child.ticket4(args);
		
	}
}
