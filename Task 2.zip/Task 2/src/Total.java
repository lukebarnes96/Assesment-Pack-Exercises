
public class Total {
	
	//Attempted to collect a running total from the four ticket classes
	public static int totalAmount=0; 
	
	public static void getTotalAmount() {
		
	
	}
}
