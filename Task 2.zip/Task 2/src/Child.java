import java.util.Scanner;

public class Child extends Student {
	
	public static void ticket4 (String[] args) {

        Scanner input = new Scanner(System.in);

        int Child = 4, quantity = 0 ;
        int sum4;
        
        System.out.print("How many Child tickets would you like to purchase?: ");
        quantity = input.nextInt();
        
        sum4 = Child * quantity;
                        
        System.out.println("The price for Child tickets is: "+sum4);
        
	
    }

	
}