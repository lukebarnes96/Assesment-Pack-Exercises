import java.util.Scanner;

public class Student extends OAP {
	
	public static void ticket3 (String[] args) {

        Scanner input = new Scanner(System.in);

        int Student = 6, quantity = 0 ;
        int sum3;

        System.out.print("How many Student tickets would you like to purchase?: ");
        quantity = input.nextInt();
        
        sum3 = Student * quantity;
        
        System.out.println("The price for Student tickets is: "+sum3);
	
    }
}