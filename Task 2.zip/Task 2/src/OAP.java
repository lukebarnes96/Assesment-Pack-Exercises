import java.util.Scanner;

public class OAP extends Standard {
	
	public static void ticket2 (String[] args) {

        Scanner input = new Scanner(System.in);

        int OAP = 6, quantity = 0 ;
        int sum2;

        System.out.print("How many OAP tickets would you like to purchase?: ");
        quantity = input.nextInt();
        
        sum2 = OAP * quantity;
        
        System.out.println("The price for OAP tickets is: "+sum2);
	
    }
}