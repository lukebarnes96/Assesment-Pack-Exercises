import java.util.Scanner;

public class Standard {
	
	//Attempted to encapsulate but couldn't access the class from a private class
	
	public static void ticket1 (String[] args) {

        Scanner input = new Scanner(System.in);

		int standard = 8, quantity = 0 ;
        int sum1; 
                
        System.out.print("How many standard tickets would you like to purchase?: ");
        quantity = input.nextInt();
        
         sum1 = standard * quantity;
                 
        System.out.println("The price for standard tickets is: "+sum1);
        
        //public void gettotalAmount (sum1);
	
    }



	
}